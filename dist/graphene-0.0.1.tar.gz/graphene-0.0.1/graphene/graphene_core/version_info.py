class VersionInfo:
    def __init__(self, name: str, version: str, build_number: str):
        self.name = name
        self.version = version
        self.build_number = build_number
