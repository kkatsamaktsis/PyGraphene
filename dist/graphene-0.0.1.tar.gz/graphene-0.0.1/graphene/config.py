
class Config:
    corenlp_client = None

    coreference_resolver_config = ["graphene_core.coreference.impl.stanford.stanford_coref", "StanfordCoref"]
